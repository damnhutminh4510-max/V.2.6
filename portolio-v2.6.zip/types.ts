export enum Page {
  Introduction = 'INTRODUCTION',
  Experience = 'EXPERIENCE',
  Projects = 'PROJECTS',
  Certifications = 'CERTIFICATIONS',
  Skills = 'SKILLS',
  Settings = 'SETTINGS',
}

export interface SocialLink {
    name: string;
    url: string;
    icon: string; // SVG path or component name
}

export interface PersonalInfo {
  name: string;
  portfolioName: string;
  age: number;
  address: string;
  school: string;
  hobbies: string[];
  careerGoal: string;
  avatarUrl: string;
  logoUrl: string;
  jobTitle: string;
  socials: SocialLink[];
}

export interface Experience {
  company: string;
  jobTitle: string;
  period: string;
  responsibilities: string[];
}

export interface MediaItem {
  type: 'image' | 'video';
  url: string;
  caption?: string;
}

export interface SubProject {
  title: string;
  description: string;
  media?: MediaItem[];
}

export interface Project {
  title: string;
  description: string;
  detailedDescription?: string;
  technologies: string[];
  imageUrl: string;
  liveDemoUrl?: string;
  sourceCodeUrl?: string;
  mediaGallery?: MediaItem[];
  subProjects?: SubProject[];
}

export interface Certificate {
  name: string;
  issuer: string;
  date: string;
  imageUrl: string;
  verifyUrl?: string;
}

export interface Skill {
  name: string;
  level: number; // Percentage from 0 to 100
}

export interface SkillCategory {
  name: string;
  skills: Skill[];
}


export interface ThemeSettings {
  bgColor: string;
  textColor: string;
  accentColor: string;
  fontHeading: string;
  fontBody: string;
  bgImageUrl: string;
  headerBgColor: string;
  headerTextColor: string;
  backgroundMusicUrl: string;
  backgroundMusicVolume: number;
  sliderSpeed: number;
  isPasswordProtectionEnabled: boolean;
  sitePassword: string;
}