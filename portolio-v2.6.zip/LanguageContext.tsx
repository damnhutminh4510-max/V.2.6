import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';

const translations = {
  vi: {
    INTRODUCTION: 'Giới thiệu',
    EXPERIENCE: 'Kinh nghiệm',
    PROJECTS: 'Dự án',
    CERTIFICATIONS: 'Chứng chỉ',
    SKILLS: 'Kỹ năng',
    SETTINGS: 'Cài đặt',
    logout: 'Đăng xuất',
    openMainMenu: 'Mở menu chính',
    personalInfo: 'Thông tin cá nhân',
    age: 'Tuổi',
    yearsOld: 'tuổi',
    address: 'Địa chỉ',
    school: 'Trường học',
    careerGoals: 'Mục tiêu nghề nghiệp',
    workExperience: 'Kinh nghiệm làm việc',
    featuredProjects: 'Dự án nổi bật',
    verify: 'Xác thực',
    backToProjects: 'Quay lại danh sách dự án',
    mediaGallery: 'Thư viện phương tiện',
    projectDetails: 'Chi tiết dự án',
    technologiesUsed: 'Công nghệ sử dụng',
    liveDemo: 'Live Demo',
    sourceCode: 'Source Code',
    skillsAndAbilities: 'Kỹ năng',
    settingsTitle: 'Cài đặt trang',
    siteSecurity: 'Bảo mật trang web',
    sitePassword: 'Mật khẩu trang web',
    sitePasswordPlaceholder: 'Đặt mật khẩu để bật tính năng bảo mật',
    requirePassword: 'Yêu cầu mật khẩu khi truy cập',
    requirePasswordDesc: 'Nếu bật, người dùng sẽ phải nhập mật khẩu để xem nội dung trang.',
    requirePasswordDescDisabled: 'Vui lòng đặt mật khẩu ở trên trước khi bật tính năng này.',
    appearanceTheme: 'Giao diện & Chủ đề',
    // Add all other UI strings here...
    adminLoginTitle: 'Đăng nhập Admin',
    username: 'Tài khoản',
    password: 'Mật khẩu',
    login: 'Đăng nhập',
    loginError: 'Tài khoản hoặc mật khẩu không chính xác.',
    accessRequired: 'Yêu cầu quyền truy cập',
    enterPasswordPrompt: 'Vui lòng nhập mật khẩu để xem nội dung.',
    unlock: 'Mở khóa',
    wrongPassword: 'Mật khẩu không chính xác.',
    forgotPassword: 'Quên mật khẩu? Đăng nhập với tư cách Admin',
    adminLoginAndUnlock: 'Đăng nhập & Mở khóa',
    enterSitePassword: 'Nhập mật khẩu trang web',
    wrongAdminCredentials: 'Tài khoản hoặc mật khẩu admin không chính xác.',
    uploadFromComputer: 'Tải lên từ máy tính',
  },
  en: {
    INTRODUCTION: 'Introduction',
    EXPERIENCE: 'Experience',
    PROJECTS: 'Projects',
    CERTIFICATIONS: 'Certifications',
    SKILLS: 'Skills',
    SETTINGS: 'Settings',
    logout: 'Logout',
    openMainMenu: 'Open main menu',
    personalInfo: 'Personal Information',
    age: 'Age',
    yearsOld: 'years old',
    address: 'Address',
    school: 'School',
    careerGoals: 'Career Goals',
    workExperience: 'Work Experience',
    featuredProjects: 'Featured Projects',
    verify: 'Verify',
    backToProjects: 'Back to project list',
    mediaGallery: 'Media Gallery',
    projectDetails: 'Project Details',
    technologiesUsed: 'Technologies Used',
    liveDemo: 'Live Demo',
    sourceCode: 'Source Code',
    skillsAndAbilities: 'Skills',
    settingsTitle: 'Site Settings',
    siteSecurity: 'Site Security',
    sitePassword: 'Site Password',
    sitePasswordPlaceholder: 'Set a password to enable protection',
    requirePassword: 'Require password to access',
    requirePasswordDesc: 'If enabled, visitors will need to enter the password to view the site.',
    requirePasswordDescDisabled: 'Please set a password above before enabling this feature.',
    appearanceTheme: 'Appearance & Theme',
    // Add all other UI strings here...
    adminLoginTitle: 'Admin Login',
    username: 'Username',
    password: 'Password',
    login: 'Login',
    loginError: 'Incorrect username or password.',
    accessRequired: 'Access Required',
    enterPasswordPrompt: 'Please enter the password to view the content.',
    unlock: 'Unlock',
    wrongPassword: 'Incorrect password.',
    forgotPassword: 'Forgot password? Log in as Admin',
    adminLoginAndUnlock: 'Login & Unlock',
    enterSitePassword: 'Enter site password',
    wrongAdminCredentials: 'Incorrect admin username or password.',
    uploadFromComputer: 'Upload from computer',
  },
};

type Language = 'vi' | 'en';
type TranslationKey = keyof typeof translations.vi;

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: TranslationKey) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('vi');

  const t = useCallback((key: TranslationKey): string => {
    return translations[language][key] || key;
  }, [language]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
