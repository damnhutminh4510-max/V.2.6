import type { PersonalInfo, Experience, Project, Certificate, ThemeSettings, SkillCategory } from './types';

// VIETNAMESE DATA
export const PERSONAL_INFO_VI: PersonalInfo = {
  name: 'ĐÀM NHỰT MINH',
  portfolioName: 'MyPortfolio',
  jobTitle: 'Performance Marketing Specialist',
  age: 23,
  address: 'TP. Hồ Chí Minh, Việt Nam',
  school: 'Đại học Kinh tế - Tài chính TP.HCM (UEF)',
  hobbies: ['Digital Marketing', 'Phân tích dữ liệu', 'SEO'],
  careerGoal: `**Mục tiêu ngắn hạn:**
- Nâng cao kiến thức và kỹ năng chuyên sâu về Digital Ads (Google Ads, Facebook Ads, SEO).
- Tham gia môi trường thực tập hoặc vị trí Junior để rèn luyện khả năng phân tích dữ liệu và tối ưu chiến dịch quảng cáo.

**Mục tiêu dài hạn:**
- Trở thành Performance Marketing Specialist, chịu trách nhiệm xây dựng chiến lược và quản lý ngân sách quảng cáo hiệu quả.
- Phát triển năng lực đo lường, tối ưu ROI và triển khai các chiến dịch Marketing đa kênh bền vững.`,
  avatarUrl: 'https://i.ibb.co/689b2PZ/avatar.jpg',
  logoUrl: '',
  socials: [
      { name: 'GitHub', url: 'https://github.com', icon: 'github' },
      { name: 'LinkedIn', url: 'https://linkedin.com', icon: 'linkedin' }
  ]
};

export const WORK_EXPERIENCE_VI: Experience[] = [
  {
    company: 'CÔNG TY CỔ PHẦN VIETNAM BOOKING',
    jobTitle: 'Thực tập sinh SEO Website',
    period: '04/2025 - 07/2025',
    responsibilities: [
      'On-page SEO: Xây dựng Topical Map, lên outline bài viết, sáng tạo content chuẩn SEO, tối ưu hình ảnh, audit và đăng bài trên CMS.',
      'Off-page SEO: Xây dựng hệ thống liên kết mạng xã hội, tăng độ phủ thương hiệu và cải thiện thứ hạng từ khóa.'
    ]
  }
];

export const PROJECTS_VI: Project[] = [
  {
    title: 'Hệ thống Quản lý Bán hàng',
    description: 'Một ứng dụng web giúp doanh nghiệp quản lý sản phẩm, đơn hàng, và khách hàng một cách hiệu quả.',
    detailedDescription: 'Hệ thống Quản lý Bán hàng là một giải pháp toàn diện được xây dựng để đơn giản hóa các hoạt động kinh doanh. Nó cung cấp các module cho quản lý kho, theo dõi đơn hàng, quản lý quan hệ khách hàng (CRM), và tạo báo cáo phân tích. Giao diện được thiết kế thân thiện, responsive trên mọi thiết bị, giúp người dùng dễ dàng truy cập và quản lý công việc mọi lúc, mọi nơi.',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Redux Toolkit', 'Node.js'],
    imageUrl: 'https://images.unsplash.com/photo-1554734867-bf3c00a49371?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#',
    sourceCodeUrl: '#',
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Giao diện thanh toán' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1586473215904-a2932e6a5831?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Bảng điều khiển quản trị' },
      { type: 'video', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', caption: 'Video giới thiệu tính năng' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Tích hợp báo cáo' },
    ],
    subProjects: [
      { title: 'Module Quản lý Kho', description: 'Theo dõi số lượng tồn kho theo thời gian thực, nhận cảnh báo khi sắp hết hàng và quản lý nhà cung cấp. Tự động cập nhật số lượng sau mỗi đơn hàng thành công.' },
      { title: 'Module CRM Khách hàng', description: 'Lưu trữ thông tin khách hàng, lịch sử mua hàng và các tương tác. Phân loại khách hàng tiềm năng và xây dựng các chiến dịch marketing mục tiêu.' }
    ]
  },
  {
    title: 'Trang Web Thương mại Điện tử',
    description: 'Xây dựng một cửa hàng online hoàn chỉnh với các tính năng giỏ hàng, thanh toán, và quản lý sản phẩm.',
    detailedDescription: 'Dự án này là một trang web e-commerce đầy đủ chức năng, tích hợp cổng thanh toán an toàn Stripe. Khách hàng có thể duyệt sản phẩm theo danh mục, thêm vào giỏ hàng, và thanh toán một cách dễ dàng. Bảng quản trị cho phép chủ cửa hàng quản lý sản phẩm, xem đơn hàng và theo dõi doanh thu. Nền tảng được xây dựng trên Next.js để tối ưu SEO và hiệu năng tải trang.',
    technologies: ['Next.js', 'Stripe', 'GraphQL', 'PostgreSQL'],
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#', sourceCodeUrl: '#', mediaGallery: [], subProjects: []
  },
  {
    title: 'Ứng dụng Chat Real-time',
    description: 'Một ứng dụng chat thời gian thực sử dụng WebSocket, cho phép người dùng giao tiếp tức thì.',
    detailedDescription: 'Ứng dụng chat này sử dụng công nghệ WebSocket qua thư viện Socket.IO để cho phép giao tiếp hai chiều theo thời gian thực giữa các client. Người dùng có thể tạo phòng chat, gửi tin nhắn văn bản, và nhận thông báo tức thì. Backend được xây dựng bằng Node.js và Express, với MongoDB để lưu trữ lịch sử tin nhắn.',
    technologies: ['React', 'Socket.IO', 'Express.js', 'MongoDB'],
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#', sourceCodeUrl: '#', mediaGallery: [], subProjects: []
  }
];

export const CERTIFICATIONS_VI: Certificate[] = [
  { name: 'AWS Certified Cloud Practitioner', issuer: 'Amazon Web Services', date: 'Tháng 10, 2022', imageUrl: 'https://images.unsplash.com/photo-1605648515299-ba54b5133703?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' },
  { name: 'Responsive Web Design', issuer: 'freeCodeCamp', date: 'Tháng 3, 2020', imageUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' },
  { name: 'Google UX Design Professional Certificate', issuer: 'Coursera', date: 'Tháng 8, 2023', imageUrl: 'https://images.unsplash.com/photo-1509343256512-d77a5cb3791b?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' }
];

export const SKILLS_DATA_VI: SkillCategory[] = [
  { name: "Kỹ năng", skills: [
      { name: "SEO Tools: Screaming Frog, SEMRush", level: 75 },
      { name: "Thiết kế Landing Page", level: 60 },
      { name: "Phân tích dữ liệu", level: 70 },
      { name: "AI & Chatbot", level: 85 },
      { name: "Thiết kế và chỉnh sửa ảnh, video", level: 80 },
  ]},
  { name: "Kỹ năng viết và biên tập nội dung", skills: [
      { name: "Kỹ năng viết và biên tập nội dung", level: 90 },
      { name: "Hành chính văn phòng", level: 75 },
  ]}
];

// ENGLISH DATA
export const PERSONAL_INFO_EN: PersonalInfo = {
  name: 'DAM NHUT MINH',
  portfolioName: 'MyPortfolio',
  jobTitle: 'Performance Marketing Specialist',
  age: 23,
  address: 'Ho Chi Minh City, Vietnam',
  school: 'Ho Chi Minh City University of Economics and Finance (UEF)',
  hobbies: ['Digital Marketing', 'Data Analysis', 'SEO'],
  careerGoal: `**Short-term goals:**
- Enhance in-depth knowledge and skills in Digital Ads (Google Ads, Facebook Ads, SEO).
- Join an internship or Junior position to practice data analysis and advertising campaign optimization.

**Long-term goals:**
- Become a Performance Marketing Specialist, responsible for building strategies and managing advertising budgets effectively.
- Develop the ability to measure, optimize ROI, and implement sustainable multi-channel Marketing campaigns.`,
  avatarUrl: 'https://i.ibb.co/689b2PZ/avatar.jpg',
  logoUrl: '',
  socials: [
      { name: 'GitHub', url: 'https://github.com', icon: 'github' },
      { name: 'LinkedIn', url: 'https://linkedin.com', icon: 'linkedin' }
  ]
};

export const WORK_EXPERIENCE_EN: Experience[] = [
  {
    company: 'VIETNAM BOOKING JOINT STOCK COMPANY',
    jobTitle: 'SEO Website Intern',
    period: 'Apr 2025 - Jul 2025',
    responsibilities: [
      'On-page SEO: Building Topical Maps, creating article outlines, writing SEO-standard content, optimizing images, auditing, and publishing posts on CMS.',
      'Off-page SEO: Building a social media link system, increasing brand coverage, and improving keyword rankings.'
    ]
  }
];

export const PROJECTS_EN: Project[] = [
  {
    title: 'Sales Management System',
    description: 'A web application to help businesses manage products, orders, and customers efficiently.',
    detailedDescription: 'The Sales Management System is a comprehensive solution built to simplify business operations. It provides modules for inventory management, order tracking, customer relationship management (CRM), and analytical reporting. The interface is user-friendly and responsive on all devices, helping users easily access and manage their work anytime, anywhere.',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Redux Toolkit', 'Node.js'],
    imageUrl: 'https://images.unsplash.com/photo-1554734867-bf3c00a49371?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#',
    sourceCodeUrl: '#',
    mediaGallery: [
      { type: 'image', url: 'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Checkout Interface' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1586473215904-a2932e6a5831?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Admin Dashboard' },
      { type: 'video', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', caption: 'Feature Introduction Video' },
      { type: 'image', url: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=800', caption: 'Reporting Integration' },
    ],
    subProjects: [
      { title: 'Inventory Management Module', description: 'Track inventory levels in real-time, receive low-stock alerts, and manage suppliers. Automatically update quantities after each successful order.' },
      { title: 'Customer CRM Module', description: 'Store customer information, purchase history, and interactions. Segment potential customers and build targeted marketing campaigns.' }
    ]
  },
  {
    title: 'E-commerce Website',
    description: 'Building a complete online store with cart, payment, and product management features.',
    detailedDescription: 'This project is a full-featured e-commerce website integrated with the secure Stripe payment gateway. Customers can browse products by category, add to cart, and check out easily. The admin panel allows the store owner to manage products, view orders, and track revenue. The platform is built on Next.js for optimized SEO and page load performance.',
    technologies: ['Next.js', 'Stripe', 'GraphQL', 'PostgreSQL'],
    imageUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#', sourceCodeUrl: '#', mediaGallery: [], subProjects: []
  },
  {
    title: 'Real-time Chat Application',
    description: 'A real-time chat application using WebSockets, allowing users to communicate instantly.',
    detailedDescription: 'This chat application uses WebSocket technology via the Socket.IO library to enable real-time, bi-directional communication between clients. Users can create chat rooms, send text messages, and receive instant notifications. The backend is built with Node.js and Express, with MongoDB for storing message history.',
    technologies: ['React', 'Socket.IO', 'Express.js', 'MongoDB'],
    imageUrl: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600',
    liveDemoUrl: '#', sourceCodeUrl: '#', mediaGallery: [], subProjects: []
  }
];

export const CERTIFICATIONS_EN: Certificate[] = [
  { name: 'AWS Certified Cloud Practitioner', issuer: 'Amazon Web Services', date: 'October 2022', imageUrl: 'https://images.unsplash.com/photo-1605648515299-ba54b5133703?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' },
  { name: 'Responsive Web Design', issuer: 'freeCodeCamp', date: 'March 2020', imageUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' },
  { name: 'Google UX Design Professional Certificate', issuer: 'Coursera', date: 'August 2023', imageUrl: 'https://images.unsplash.com/photo-1509343256512-d77a5cb3791b?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb&w=600', verifyUrl: '#' }
];

export const SKILLS_DATA_EN: SkillCategory[] = [
    { name: "Skills", skills: [
        { name: "SEO Tools: Screaming Frog, SEMRush", level: 75 },
        { name: "Landing Page Design", level: 60 },
        { name: "Data Analysis", level: 70 },
        { name: "AI & Chatbot", level: 85 },
        { name: "Photo and Video Design & Editing", level: 80 },
    ]},
    { name: "Content Writing and Editing Skills", skills: [
        { name: "Content Writing and Editing Skills", level: 90 },
        { name: "Office Administration", level: 75 },
    ]}
];


// SHARED SETTINGS
export const INITIAL_THEME_SETTINGS: ThemeSettings = {
  bgColor: '#0F172A',
  textColor: '#CBD5E1',
  accentColor: '#22D3EE',
  fontHeading: "'Poppins', sans-serif",
  fontBody: "'Inter', sans-serif",
  bgImageUrl: '',
  headerBgColor: 'rgba(255, 255, 255, 0.1)',
  headerTextColor: '#E2E8F0', // slate-200
  backgroundMusicUrl: '',
  backgroundMusicVolume: 0.5,
  sliderSpeed: 30,
  isPasswordProtectionEnabled: false,
  sitePassword: '',
};

export const AVAILABLE_FONTS = [
  { name: 'Poppins', value: "'Poppins', sans-serif" },
  { name: 'Inter', value: "'Inter', sans-serif" },
  { name: 'Lato', value: "'Lato', sans-serif" },
  { name: 'Montserrat', value: "'Montserrat', sans-serif" },
  { name: 'Roboto Slab', value: "'Roboto Slab', serif" },
];