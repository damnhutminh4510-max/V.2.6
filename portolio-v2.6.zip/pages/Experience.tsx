import React from 'react';
import { Experience as ExperienceType } from '../types';
import { useLanguage } from '../LanguageContext';

interface ExperienceProps {
  workExperience: ExperienceType[];
}

const Experience: React.FC<ExperienceProps> = ({ workExperience }) => {
  const { t } = useLanguage();
  return (
    <section className="animate-fadeInUp">
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center text-white mb-12 md:mb-16" style={{ fontFamily: 'var(--font-heading)' }}>{t('workExperience')}</h1>
      <div className="relative border-l-2 border-cyan-400/30 ml-4 md:mx-auto md:max-w-3xl">
        {workExperience.map((exp, index) => (
          <div key={index} className="mb-12 ml-10 stagger-children">
             <span className="absolute flex items-center justify-center w-8 h-8 bg-slate-800 rounded-full -left-4 ring-8 ring-slate-900 border-2 border-cyan-400">
               <svg className="w-4 h-4 text-cyan-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd"></path></svg>
             </span>
            <div
              className="bg-slate-800/60 backdrop-blur-lg p-6 rounded-2xl shadow-lg border border-slate-700/50 transition-all duration-300 hover:shadow-cyan-500/10 hover:-translate-y-1"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
                <h3 className="text-2xl font-bold text-white" style={{fontFamily: 'var(--font-heading)'}}>{exp.jobTitle}</h3>
                <p className="text-lg font-semibold text-cyan-400 mb-1">{exp.company}</p>
                <time className="block mb-4 text-sm font-normal leading-none text-slate-400">{exp.period}</time>
                <ul className="list-disc list-inside space-y-2 text-slate-300">
                {exp.responsibilities.map((resp, i) => (
                    <li key={i}>{resp}</li>
                ))}
                </ul>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Experience;