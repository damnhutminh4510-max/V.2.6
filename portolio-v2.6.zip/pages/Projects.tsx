import React, { useRef, useEffect } from 'react';
import { Project } from '../types';
import { useLanguage } from '../LanguageContext';

interface ProjectsProps {
  projects: Project[];
  onProjectSelect: (project: Project) => void;
}

const Projects: React.FC<ProjectsProps> = ({ projects, onProjectSelect }) => {
  const { t } = useLanguage();
  const imageRefs = useRef<(HTMLImageElement | null)[]>([]);

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          imageRefs.current.forEach(img => {
            if (!img || !img.parentElement) return;

            const parentRect = img.parentElement.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            if (parentRect.bottom < 0 || parentRect.top > viewportHeight) return;
            
            const elementCenter = parentRect.top + parentRect.height / 2;
            const viewportCenter = viewportHeight / 2;
            const centerOffset = (elementCenter - viewportCenter) / viewportCenter;
            const maxOffset = 20; 
            const parallaxOffset = Math.max(-maxOffset, Math.min(maxOffset, centerOffset * -maxOffset));
            
            img.style.transform = `scale(1.15) translateY(${parallaxOffset}px)`;
          });
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [projects]);

  return (
    <section className="animate-fadeInUp">
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center text-white mb-12 md:mb-16" style={{ fontFamily: 'var(--font-heading)' }}>{t('featuredProjects')}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 stagger-children [perspective:1000px]">
        {projects.map((project, index) => (
          <button 
            key={index}
            onClick={() => onProjectSelect(project)}
            className="group text-left relative bg-slate-800/60 rounded-2xl shadow-lg overflow-hidden border border-slate-700/50 flex flex-col [transform-style:preserve-3d] transition-all duration-500 ease-out hover:shadow-cyan-400/20 hover:[transform:rotateX(3deg)_rotateY(-4deg)_scale(1.03)] focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-slate-900"
            style={{ animationDelay: `${index * 0.15}s` }}
            >
            <div className="absolute -inset-px bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
            <div className="relative flex flex-col flex-grow">
              <div className="h-52 overflow-hidden">
                <img
                  ref={el => { imageRefs.current[index] = el; }}
                  src={project.imageUrl}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-300"
                  style={{ transform: 'scale(1.15)' }}
                />
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-2xl font-semibold text-white mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{project.title}</h3>
                <p className="text-slate-400 mb-4 flex-grow">{project.description.substring(0, 100)}{project.description.length > 100 ? '...' : ''}</p>
                 <div className="mt-auto pt-4 border-t border-slate-700/50">
                   <p className="text-sm text-center font-semibold text-cyan-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                     {t('projectDetails')}
                   </p>
                 </div>
              </div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
};

export default Projects;