import React, { useState } from 'react';
import { useLanguage } from '../LanguageContext';

interface LoginProps {
  onLoginSuccess: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { t } = useLanguage();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'Minh' && password === '2004') {
      setError('');
      onLoginSuccess();
    } else {
      setError(t('loginError'));
    }
  };

  const commonInputClass = "w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500";
  const commonButtonClass = "w-full bg-cyan-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-cyan-500 transition-colors duration-200 disabled:bg-slate-600";

  return (
    <section className="animate-fadeInUp max-w-md mx-auto">
      <div className="bg-slate-800/80 p-8 rounded-xl shadow-lg border border-slate-700">
        <h1 className="text-3xl font-bold text-center text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
          {t('adminLoginTitle')}
        </h1>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-cyan-400 mb-2">
              {t('username')}
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className={commonInputClass}
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-cyan-400 mb-2">
              {t('password')}
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className={commonInputClass}
            />
          </div>
          {error && <p className="text-red-500 text-sm text-center">{error}</p>}
          <div>
            <button type="submit" className={commonButtonClass}>
              {t('login')}
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default Login;