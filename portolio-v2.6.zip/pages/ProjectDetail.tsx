import React, { useState } from 'react';
import { Project } from '../types';
import Lightbox from '../components/Lightbox';
import { useLanguage } from '../LanguageContext';

interface ProjectDetailProps {
  project: Project;
  onBack: () => void;
}

const ProjectDetail: React.FC<ProjectDetailProps> = ({ project, onBack }) => {
  const [isLightboxOpen, setLightboxOpen] = useState(false);
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const { t } = useLanguage();

  const openLightbox = (index: number) => {
    setSelectedMediaIndex(index);
    setLightboxOpen(true);
  };

  const hasMediaGallery = project.mediaGallery && project.mediaGallery.length > 0;
  const hasSubProjects = project.subProjects && project.subProjects.length > 0;

  return (
    <>
    <section className="animate-fadeInUp max-w-5xl mx-auto">
        <button 
            onClick={onBack}
            className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors duration-200 mb-8 font-semibold"
        >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
            {t('backToProjects')}
        </button>

        <div className="bg-slate-800/80 backdrop-blur-sm rounded-xl shadow-2xl overflow-hidden border border-slate-700">
            <div className="relative w-full h-80 md:h-96">
                <img src={project.imageUrl} alt={project.title} className="w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-800 via-slate-800/50 to-transparent"></div>
            </div>
            <div className="p-6 md:p-10 -mt-20 relative">
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>{project.title}</h1>
                <p className="text-lg leading-relaxed text-slate-300 mb-12 whitespace-pre-wrap">{project.detailedDescription || project.description}</p>
                
                {hasMediaGallery && (
                    <div className="mb-12">
                        <h2 className="text-2xl font-bold text-white border-l-4 border-cyan-500 pl-4 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>{t('mediaGallery')}</h2>
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                            {project.mediaGallery?.map((media, index) => (
                                <button key={index} onClick={() => openLightbox(index)} className="group relative aspect-square bg-slate-700 rounded-lg overflow-hidden focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 focus:ring-offset-slate-800">
                                    <img src={media.type === 'image' ? media.url : `https://i.ibb.co/689b2PZ/avatar.jpg`} alt={media.caption || ''} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
                                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                                        {media.type === 'video' && (
                                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-white/80 w-12 h-12 drop-shadow-lg"><circle cx="12" cy="12" r="10"></circle><polygon points="10 8 16 12 10 16 10 8"></polygon></svg>
                                        )}
                                         {media.type === 'image' && (
                                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-white/80 w-12 h-12 drop-shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                        )}
                                    </div>
                                    {media.caption && <p className="absolute bottom-0 left-0 right-0 p-2 bg-black/60 text-white text-xs truncate">{media.caption}</p>}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {hasSubProjects && (
                    <div className="mb-12">
                         <h2 className="text-2xl font-bold text-white border-l-4 border-cyan-500 pl-4 mb-6" style={{ fontFamily: 'var(--font-heading)' }}>{t('projectDetails')}</h2>
                         <div className="space-y-8">
                            {project.subProjects?.map((sub, index) => (
                                <div key={index} className="bg-slate-900/60 p-6 rounded-xl border border-slate-700/80 transition-all hover:border-cyan-500/30">
                                    <h3 className="text-xl font-semibold text-cyan-300 mb-2" style={{fontFamily: 'var(--font-heading)'}}>{sub.title}</h3>
                                    <p className="text-slate-400 whitespace-pre-wrap">{sub.description}</p>
                                </div>
                            ))}
                         </div>
                    </div>
                )}
                
                <div className="mb-10">
                <h2 className="text-2xl font-bold text-white border-l-4 border-cyan-500 pl-4 mb-6" style={{fontFamily: 'var(--font-heading)'}}>{t('technologiesUsed')}</h2>
                <div className="flex flex-wrap gap-3">
                    {project.technologies.map((tech, i) => (
                        <div key={i} className="group bg-slate-700/50 border border-slate-600 rounded-full py-2 px-4 flex items-center transition-all duration-300 hover:border-cyan-400/50 hover:bg-slate-700">
                            <span className="text-cyan-400 mr-2 font-mono text-sm">#</span>
                            <span className="text-slate-300 font-medium group-hover:text-white transition-colors">{tech}</span>
                        </div>
                    ))}
                </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 pt-8 border-t border-slate-700">
                    {project.liveDemoUrl && project.liveDemoUrl !== '#' && (
                    <a 
                        href={project.liveDemoUrl} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="flex-1 inline-flex items-center justify-center bg-cyan-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-cyan-500 transition-colors duration-200 text-lg"
                    >
                        {t('liveDemo')}
                        <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path></svg>
                    </a>
                    )}
                    {project.sourceCodeUrl && project.sourceCodeUrl !== '#' && (
                    <a 
                        href={project.sourceCodeUrl} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="flex-1 inline-flex items-center justify-center bg-slate-700 text-white font-bold py-3 px-6 rounded-lg hover:bg-slate-600 transition-colors duration-200 text-lg"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path></svg>
                        {t('sourceCode')}
                    </a>
                    )}
                </div>
            </div>
        </div>
    </section>
    {hasMediaGallery && (
        <Lightbox 
            isOpen={isLightboxOpen}
            onClose={() => setLightboxOpen(false)}
            media={project.mediaGallery!}
            startIndex={selectedMediaIndex}
        />
    )}
    </>
  );
};

export default ProjectDetail;