import React from 'react';
import { PersonalInfo, Experience, Project, Certificate, ThemeSettings, SocialLink, SkillCategory, Skill, MediaItem, SubProject } from '../types';
import ImageUploader from '../components/ImageUploader';
import AudioUploader from '../components/AudioUploader';
import { AVAILABLE_FONTS } from '../constants';


interface SettingsProps {
  personalInfo: PersonalInfo;
  setPersonalInfo: React.Dispatch<React.SetStateAction<PersonalInfo>>;
  workExperience: Experience[];
  setWorkExperience: React.Dispatch<React.SetStateAction<Experience[]>>;
  projects: Project[];
  setProjects: React.Dispatch<React.SetStateAction<Project[]>>;
  certifications: Certificate[];
  setCertifications: React.Dispatch<React.SetStateAction<Certificate[]>>;
  skills: SkillCategory[];
  setSkills: React.Dispatch<React.SetStateAction<SkillCategory[]>>;
  themeSettings: ThemeSettings;
  setThemeSettings: React.Dispatch<React.SetStateAction<ThemeSettings>>;
}

const commonInputClass = "w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500";
const commonTextareaClass = `${commonInputClass} min-h-[100px]`;
const commonButtonClass = "bg-cyan-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-cyan-500 transition-colors duration-200 disabled:bg-slate-600";
const deleteButtonClass = "bg-red-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-red-500 transition-colors duration-200";
const commonLabelClass = "block text-sm font-medium text-cyan-400";
const commonSelectClass = `${commonInputClass} appearance-none`;

const MediaItemEditor: React.FC<{
    media: MediaItem;
    projectIndex: number;
    mediaIndex: number;
    handleMediaChange: (projIndex: number, mediaIndex: number, field: keyof MediaItem, value: string) => void;
    removeMedia: (projIndex: number, mediaIndex: number) => void;
}> = ({ media, projectIndex, mediaIndex, handleMediaChange, removeMedia }) => {
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const isFileUploaded = media.url.startsWith('data:');

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                handleMediaChange(projectIndex, mediaIndex, 'url', reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const triggerFileSelect = () => {
        fileInputRef.current?.click();
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-[auto,1fr,1fr,auto] gap-2 items-start p-3 border border-slate-600 rounded-lg">
            <select value={media.type} onChange={e => handleMediaChange(projectIndex, mediaIndex, 'type', e.target.value)} className={`${commonSelectClass} h-10`}>
                <option value="image">Hình ảnh</option>
                <option value="video">Video</option>
            </select>
            <div className="space-y-2">
                <input
                    type="text"
                    placeholder={isFileUploaded ? "Đã tải lên tệp cục bộ." : "URL phương tiện"}
                    value={isFileUploaded ? "" : media.url}
                    onChange={e => handleMediaChange(projectIndex, mediaIndex, 'url', e.target.value)}
                    disabled={isFileUploaded}
                    className={commonInputClass}
                />
                <input
                    type="file"
                    accept={media.type === 'image' ? 'image/*' : 'video/*'}
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                />
                <button
                    type="button"
                    onClick={triggerFileSelect}
                    className="w-full bg-slate-700 text-white font-semibold py-2 px-4 rounded-md hover:bg-slate-600 transition-colors duration-200"
                >
                    Tải lên
                </button>
            </div>
             <input type="text" placeholder="Chú thích (tùy chọn)" value={media.caption || ''} onChange={e => handleMediaChange(projectIndex, mediaIndex, 'caption', e.target.value)} className={`${commonInputClass} h-10`} />
            <div className="flex flex-col gap-2">
                 <button onClick={() => removeMedia(projectIndex, mediaIndex)} className={`${deleteButtonClass} px-3 h-10`}>Xóa</button>
                 {isFileUploaded && <button type="button" onClick={() => handleMediaChange(projectIndex, mediaIndex, 'url', '')} className="bg-yellow-600 text-white font-semibold py-1 px-3 rounded-md hover:bg-yellow-500 text-xs">Xóa tệp</button>}
            </div>
        </div>
    )
};


const Settings: React.FC<SettingsProps> = ({
  personalInfo, setPersonalInfo,
  workExperience, setWorkExperience,
  projects, setProjects,
  certifications, setCertifications,
  skills, setSkills,
  themeSettings, setThemeSettings
}) => {

  const handlePersonalInfoChange = (field: keyof PersonalInfo, value: any) => {
    setPersonalInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleSocialLinkChange = (index: number, field: keyof SocialLink, value: string) => {
    const newSocials = [...personalInfo.socials];
    const newLink = { ...newSocials[index], [field]: value };

    if (field === 'icon') {
      const oldIcon = newSocials[index].icon;
      const oldName = oldIcon.charAt(0).toUpperCase() + oldIcon.slice(1);
      if (newSocials[index].name === oldName || newSocials[index].name === '') {
        newLink.name = value.charAt(0).toUpperCase() + value.slice(1);
      }
    }
    newSocials[index] = newLink;
    handlePersonalInfoChange('socials', newSocials);
  };
  
  const addSocialLink = () => {
    const newSocials = [...personalInfo.socials, { name: 'Website', url: '', icon: 'link' }];
    handlePersonalInfoChange('socials', newSocials);
  };

  const removeSocialLink = (index: number) => {
    const newSocials = personalInfo.socials.filter((_, i) => i !== index);
    handlePersonalInfoChange('socials', newSocials);
  };

  const handleThemeChange = (field: keyof ThemeSettings, value: any) => {
    setThemeSettings(prev => ({ ...prev, [field]: value }));
  };
  
  const handleArrayChange = <T,>(setter: React.Dispatch<React.SetStateAction<T[]>>, index: number, field: keyof T, value: any) => {
    setter(prev => {
      const newArr = [...prev];
      newArr[index] = { ...newArr[index], [field]: value };
      return newArr;
    });
  };

  const addToArray = <T,>(setter: React.Dispatch<React.SetStateAction<T[]>>, newItem: T) => {
    setter(prev => [...prev, newItem]);
  };
  
  const removeFromArray = <T,>(setter: React.Dispatch<React.SetStateAction<T[]>>, index: number) => {
    setter(prev => prev.filter((_, i) => i !== index));
  };
  
  const handleSkillCategoryChange = (catIndex: number, field: keyof SkillCategory, value: any) => {
    handleArrayChange(setSkills, catIndex, field, value);
  };

  const addSkillCategory = () => {
    addToArray(setSkills, { name: 'New Category', skills: [] });
  };

  const removeSkillCategory = (catIndex: number) => {
    removeFromArray(setSkills, catIndex);
  };

  const handleSkillChange = (catIndex: number, skillIndex: number, field: keyof Skill, value: any) => {
    setSkills(prev => {
        const newCategories = JSON.parse(JSON.stringify(prev));
        newCategories[catIndex].skills[skillIndex][field] = value;
        return newCategories;
    });
  };
  
  const addSkill = (catIndex: number) => {
    setSkills(prev => {
        const newCategories = JSON.parse(JSON.stringify(prev));
        newCategories[catIndex].skills.push({ name: 'New Skill', level: 50 });
        return newCategories;
    });
  };

  const removeSkill = (catIndex: number, skillIndex: number) => {
     setSkills(prev => {
        const newCategories = JSON.parse(JSON.stringify(prev));
        newCategories[catIndex].skills.splice(skillIndex, 1);
        return newCategories;
    });
  };

  const handleProjectFieldChange = (projIndex: number, field: keyof Project, value: any) => {
    handleArrayChange(setProjects, projIndex, field, value);
  };
  
  const handleMediaChange = (projIndex: number, mediaIndex: number, field: keyof MediaItem, value: string) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
        newProjects[projIndex].mediaGallery[mediaIndex][field] = value;
        return newProjects;
    });
  };

  const addMedia = (projIndex: number) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
        if (!newProjects[projIndex].mediaGallery) {
            newProjects[projIndex].mediaGallery = [];
        }
        newProjects[projIndex].mediaGallery.push({ type: 'image', url: '', caption: '' });
        return newProjects;
    });
  };

  const removeMedia = (projIndex: number, mediaIndex: number) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
        newProjects[projIndex].mediaGallery.splice(mediaIndex, 1);
        return newProjects;
    });
  };

  const handleSubProjectChange = (projIndex: number, subIndex: number, field: keyof SubProject, value: string) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
        newProjects[projIndex].subProjects[subIndex][field] = value;
        return newProjects;
    });
  };

  const addSubProject = (projIndex: number) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
         if (!newProjects[projIndex].subProjects) {
            newProjects[projIndex].subProjects = [];
        }
        newProjects[projIndex].subProjects.push({ title: '', description: '' });
        return newProjects;
    });
  };

  const removeSubProject = (projIndex: number, subIndex: number) => {
    setProjects(prev => {
        const newProjects = JSON.parse(JSON.stringify(prev));
        newProjects[projIndex].subProjects.splice(subIndex, 1);
        return newProjects;
    });
  };


  return (
    <section className="animate-fadeInUp space-y-8">
      <h1 className="text-4xl md:text-5xl font-bold text-center text-white" style={{ fontFamily: 'var(--font-heading)' }}>Cài đặt trang</h1>

       <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Bảo mật trang web</summary>
          <div className="mt-6 space-y-6 border-t border-slate-700 pt-6">
             <div>
                <label className={commonLabelClass}>Mật khẩu trang web</label>
                <input 
                  type="password" 
                  value={themeSettings.sitePassword} 
                  onChange={e => handleThemeChange('sitePassword', e.target.value)} 
                  className={commonInputClass}
                  placeholder="Đặt mật khẩu để bật tính năng bảo mật"
                />
              </div>
            <div className={`bg-slate-900 p-4 rounded-lg transition-opacity duration-300 ${!themeSettings.sitePassword ? 'opacity-60' : ''}`}>
              <div className="flex items-center justify-between">
                <div>
                  <label htmlFor="enable-password-protection" className={`font-semibold text-white ${!themeSettings.sitePassword ? 'cursor-not-allowed' : ''}`}>Yêu cầu mật khẩu khi truy cập</label>
                  <p className="text-sm text-slate-400">
                    {!themeSettings.sitePassword 
                      ? "Vui lòng đặt mật khẩu ở trên trước khi bật tính năng này." 
                      : "Nếu bật, người dùng sẽ phải nhập mật khẩu để xem nội dung trang."
                    }
                  </p>
                </div>
                <label htmlFor="enable-password-protection" className={`relative inline-flex items-center ${!themeSettings.sitePassword ? 'cursor-not-allowed' : 'cursor-pointer'}`}>
                  <input 
                    type="checkbox" 
                    id="enable-password-protection" 
                    className="sr-only peer" 
                    checked={themeSettings.isPasswordProtectionEnabled}
                    onChange={e => handleThemeChange('isPasswordProtectionEnabled', e.target.checked)}
                    disabled={!themeSettings.sitePassword}
                  />
                  <div className="w-11 h-6 bg-slate-600 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-600 peer-disabled:cursor-not-allowed peer-disabled:opacity-50"></div>
                </label>
              </div>
            </div>
          </div>
        </details>
      </div>
      
       <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Giao diện & Chủ đề</summary>
          <div className="mt-6 space-y-6 border-t border-slate-700 pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className={commonLabelClass}>Màu nền</label>
                <input type="color" value={themeSettings.bgColor} onChange={e => handleThemeChange('bgColor', e.target.value)} className="w-full h-10 p-1 bg-slate-900 border border-slate-700 rounded-md cursor-pointer" />
              </div>
              <div>
                <label className={commonLabelClass}>Màu chữ chính</label>
                <input type="color" value={themeSettings.textColor} onChange={e => handleThemeChange('textColor', e.target.value)} className="w-full h-10 p-1 bg-slate-900 border border-slate-700 rounded-md cursor-pointer" />
              </div>
              <div>
                <label className={commonLabelClass}>Màu nhấn</label>
                <input type="color" value={themeSettings.accentColor} onChange={e => handleThemeChange('accentColor', e.target.value)} className="w-full h-10 p-1 bg-slate-900 border border-slate-700 rounded-md cursor-pointer" />
              </div>
            </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className={commonLabelClass}>Màu nền Header (e.g., rgba(255,255,255,0.1))</label>
                  <input type="text" value={themeSettings.headerBgColor} onChange={e => handleThemeChange('headerBgColor', e.target.value)} className={commonInputClass} />
                </div>
                <div>
                  <label className={commonLabelClass}>Màu chữ Header</label>
                  <input type="text" value={themeSettings.headerTextColor} onChange={e => handleThemeChange('headerTextColor', e.target.value)} className={commonInputClass} />
                </div>
              </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className={commonLabelClass}>Font chữ tiêu đề</label>
                <select value={themeSettings.fontHeading} onChange={e => handleThemeChange('fontHeading', e.target.value)} className={commonSelectClass}>
                  {AVAILABLE_FONTS.map(font => <option key={font.name} value={font.value}>{font.name}</option>)}
                </select>
              </div>
               <div>
                <label className={commonLabelClass}>Font chữ nội dung</label>
                <select value={themeSettings.fontBody} onChange={e => handleThemeChange('fontBody', e.target.value)} className={commonSelectClass}>
                  {AVAILABLE_FONTS.map(font => <option key={font.name} value={font.value}>{font.name}</option>)}
                </select>
              </div>
            </div>
            <div>
                <label className={commonLabelClass}>Tốc độ trượt của Slider (giây)</label>
                <div className="flex items-center gap-4">
                    <input 
                        type="range" 
                        min="5" 
                        max="120" 
                        step="1" 
                        value={themeSettings.sliderSpeed} 
                        onChange={e => handleThemeChange('sliderSpeed', parseInt(e.target.value, 10))}
                        className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                    />
                    <span className="text-sm text-slate-300 w-16 text-right">
                        {themeSettings.sliderSpeed} giây
                    </span>
                </div>
            </div>
             <div>
                <ImageUploader 
                    label="Ảnh nền trang" 
                    currentImageUrl={themeSettings.bgImageUrl} 
                    onImageUrlChange={url => handleThemeChange('bgImageUrl', url)} 
                />
                {themeSettings.bgImageUrl && (
                    <button 
                        onClick={() => handleThemeChange('bgImageUrl', '')} 
                        className="mt-2 bg-yellow-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-500 transition-colors duration-200"
                    >
                        Xóa ảnh nền
                    </button>
                )}
            </div>
             <div className="border-t border-slate-700 pt-6 space-y-4">
                <h3 className="text-lg font-semibold text-white">Nhạc nền</h3>
                <AudioUploader
                    label="Tệp nhạc nền"
                    currentAudioUrl={themeSettings.backgroundMusicUrl}
                    onAudioUrlChange={url => handleThemeChange('backgroundMusicUrl', url)}
                />
                <div>
                    <label className={commonLabelClass}>Âm lượng</label>
                    <div className="flex items-center gap-4">
                        <input 
                            type="range" 
                            min="0" 
                            max="1" 
                            step="0.05" 
                            value={themeSettings.backgroundMusicVolume} 
                            onChange={e => handleThemeChange('backgroundMusicVolume', parseFloat(e.target.value))}
                            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer"
                        />
                        <span className="text-sm text-slate-300 w-12 text-right">
                            {Math.round(themeSettings.backgroundMusicVolume * 100)}%
                        </span>
                    </div>
                </div>
            </div>
          </div>
        </details>
      </div>

      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details open className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Thông tin cá nhân</summary>
          <div className="mt-6 space-y-6 border-t border-slate-700 pt-6">
            <ImageUploader label="Logo (Hiển thị ở Header)" currentImageUrl={personalInfo.logoUrl} onImageUrlChange={url => handlePersonalInfoChange('logoUrl', url)} />
            <ImageUploader label="Ảnh đại diện" currentImageUrl={personalInfo.avatarUrl} onImageUrlChange={url => handlePersonalInfoChange('avatarUrl', url)} />
            <div><label className={commonLabelClass}>Tên</label><input type="text" value={personalInfo.name} onChange={e => handlePersonalInfoChange('name', e.target.value)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Tên Portfolio</label><input type="text" value={personalInfo.portfolioName || ''} onChange={e => handlePersonalInfoChange('portfolioName', e.target.value)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Chức danh</label><input type="text" value={personalInfo.jobTitle} onChange={e => handlePersonalInfoChange('jobTitle', e.target.value)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Tuổi</label><input type="number" value={personalInfo.age} onChange={e => handlePersonalInfoChange('age', parseInt(e.target.value, 10) || 0)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Địa chỉ</label><input type="text" value={personalInfo.address} onChange={e => handlePersonalInfoChange('address', e.target.value)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Trường học</label><input type="text" value={personalInfo.school} onChange={e => handlePersonalInfoChange('school', e.target.value)} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Sở thích (phân cách bằng dấu phẩy)</label><input type="text" value={personalInfo.hobbies.join(', ')} onChange={e => handlePersonalInfoChange('hobbies', e.target.value.split(',').map(s => s.trim()))} className={commonInputClass} /></div>
            <div><label className={commonLabelClass}>Mục tiêu nghề nghiệp</label><textarea value={personalInfo.careerGoal} onChange={e => handlePersonalInfoChange('careerGoal', e.target.value)} className={commonTextareaClass}></textarea></div>
             
             {/* Social Links Editor */}
            <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">Mạng xã hội</h3>
                {personalInfo.socials.map((social, index) => (
                    <div key={index} className="grid grid-cols-1 sm:grid-cols-[1fr,2fr,auto] items-center gap-2 p-3 border border-slate-600 rounded-lg">
                        <select value={social.icon} onChange={e => handleSocialLinkChange(index, 'icon', e.target.value)} className={commonSelectClass}>
                            <option value="github">GitHub</option>
                            <option value="linkedin">LinkedIn</option>
                            <option value="facebook">Facebook</option>
                            <option value="twitter">Twitter</option>
                            <option value="instagram">Instagram</option>
                            <option value="link">Website</option>
                        </select>
                        <input type="text" placeholder="URL" value={social.url} onChange={e => handleSocialLinkChange(index, 'url', e.target.value)} className={commonInputClass} />
                        <button onClick={() => removeSocialLink(index)} className={`${deleteButtonClass} px-3`}>Xóa</button>
                    </div>
                ))}
                 <button onClick={addSocialLink} className={commonButtonClass}>Thêm liên kết</button>
            </div>
          </div>
        </details>
      </div>

      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Kinh nghiệm làm việc</summary>
          <div className="mt-6 space-y-8 border-t border-slate-700 pt-6">
            {workExperience.map((exp, index) => (
              <div key={index} className="space-y-4 p-4 border border-slate-600 rounded-lg">
                <div><label className={commonLabelClass}>Công ty</label><input type="text" value={exp.company} onChange={e => handleArrayChange(setWorkExperience, index, 'company', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Chức danh</label><input type="text" value={exp.jobTitle} onChange={e => handleArrayChange(setWorkExperience, index, 'jobTitle', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Thời gian</label><input type="text" value={exp.period} onChange={e => handleArrayChange(setWorkExperience, index, 'period', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Trách nhiệm (mỗi dòng một gạch đầu dòng)</label><textarea value={exp.responsibilities.join('\n')} onChange={e => handleArrayChange(setWorkExperience, index, 'responsibilities', e.target.value.split('\n'))} className={commonTextareaClass}></textarea></div>
                <button onClick={() => removeFromArray(setWorkExperience, index)} className={deleteButtonClass}>Xóa kinh nghiệm</button>
              </div>
            ))}
            <button onClick={() => addToArray(setWorkExperience, { company: '', jobTitle: '', period: '', responsibilities: [] })} className={commonButtonClass}>Thêm kinh nghiệm</button>
          </div>
        </details>
      </div>
      
      <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Kỹ năng</summary>
          <div className="mt-6 space-y-8 border-t border-slate-700 pt-6">
            {skills.map((category, catIndex) => (
              <div key={catIndex} className="space-y-4 p-4 border border-slate-600 rounded-lg">
                <div className="flex justify-between items-center">
                  <input type="text" value={category.name} onChange={e => handleSkillCategoryChange(catIndex, 'name', e.target.value)} className={`${commonInputClass} font-semibold text-lg`} />
                  <button onClick={() => removeSkillCategory(catIndex)} className={`${deleteButtonClass} ml-4`}>Xóa danh mục</button>
                </div>
                <div className="space-y-4 pt-4 border-t border-slate-700">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="grid grid-cols-1 md:grid-cols-[2fr,1fr,auto] gap-2 items-center">
                       <input type="text" placeholder="Tên kỹ năng" value={skill.name} onChange={e => handleSkillChange(catIndex, skillIndex, 'name', e.target.value)} className={commonInputClass} />
                       <div className="flex items-center gap-2">
                        <input type="range" min="0" max="100" value={skill.level} onChange={e => handleSkillChange(catIndex, skillIndex, 'level', parseInt(e.target.value))} className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer" />
                        <span className="text-sm text-slate-300 w-10 text-right">{skill.level}%</span>
                       </div>
                       <button onClick={() => removeSkill(catIndex, skillIndex)} className={`${deleteButtonClass} px-3`}>Xóa</button>
                    </div>
                  ))}
                  <button onClick={() => addSkill(catIndex)} className={commonButtonClass}>Thêm kỹ năng</button>
                </div>
              </div>
            ))}
            <button onClick={addSkillCategory} className={commonButtonClass}>Thêm danh mục kỹ năng</button>
          </div>
        </details>
      </div>

       <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details open className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Dự án</summary>
           <div className="mt-6 space-y-8 border-t border-slate-700 pt-6">
            {projects.map((proj, index) => (
              <div key={index} className="space-y-4 p-4 border border-slate-600 rounded-lg">
                 <ImageUploader label="Ảnh bìa dự án" currentImageUrl={proj.imageUrl} onImageUrlChange={url => handleProjectFieldChange(index, 'imageUrl', url)} />
                <div><label className={commonLabelClass}>Tên dự án</label><input type="text" value={proj.title} onChange={e => handleProjectFieldChange(index, 'title', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Mô tả ngắn</label><textarea value={proj.description} onChange={e => handleProjectFieldChange(index, 'description', e.target.value)} className={commonTextareaClass}></textarea></div>
                <div><label className={commonLabelClass}>Mô tả chi tiết</label><textarea value={proj.detailedDescription || ''} onChange={e => handleProjectFieldChange(index, 'detailedDescription', e.target.value)} className={commonTextareaClass}></textarea></div>
                <div><label className={commonLabelClass}>Công nghệ (phân cách bằng dấu phẩy)</label><input type="text" value={proj.technologies.join(', ')} onChange={e => handleProjectFieldChange(index, 'technologies', e.target.value.split(',').map(s => s.trim()))} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>URL Live Demo</label><input type="text" value={proj.liveDemoUrl || ''} onChange={e => handleProjectFieldChange(index, 'liveDemoUrl', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>URL Source Code</label><input type="text" value={proj.sourceCodeUrl || ''} onChange={e => handleProjectFieldChange(index, 'sourceCodeUrl', e.target.value)} className={commonInputClass} /></div>
                
                 <div className="pt-4 mt-4 border-t border-slate-700 space-y-4">
                     <h4 className="text-lg font-semibold text-white">Thư viện phương tiện</h4>
                     {proj.mediaGallery?.map((media, mediaIndex) => (
                         <MediaItemEditor 
                            key={mediaIndex} 
                            media={media} 
                            projectIndex={index} 
                            mediaIndex={mediaIndex}
                            handleMediaChange={handleMediaChange}
                            removeMedia={removeMedia}
                        />
                     ))}
                     <button onClick={() => addMedia(index)} className={commonButtonClass}>Thêm Media</button>
                 </div>

                <div className="pt-4 mt-4 border-t border-slate-700 space-y-4">
                     <h4 className="text-lg font-semibold text-white">Dự án phụ / Chi tiết</h4>
                     {proj.subProjects?.map((sub, subIndex) => (
                         <div key={subIndex} className="p-3 border border-slate-600 rounded-lg space-y-3">
                            <div className="flex justify-between items-center">
                                <label className={commonLabelClass}>Dự án phụ #{subIndex + 1}</label>
                                <button onClick={() => removeSubProject(index, subIndex)} className={`${deleteButtonClass} px-3`}>Xóa</button>
                            </div>
                            <input type="text" placeholder="Tiêu đề" value={sub.title} onChange={e => handleSubProjectChange(index, subIndex, 'title', e.target.value)} className={commonInputClass} />
                            <textarea placeholder="Mô tả" value={sub.description} onChange={e => handleSubProjectChange(index, subIndex, 'description', e.target.value)} className={commonTextareaClass}></textarea>
                         </div>
                     ))}
                     <button onClick={() => addSubProject(index)} className={commonButtonClass}>Thêm dự án phụ</button>
                 </div>

                <button onClick={() => removeFromArray(setProjects, index)} className={`${deleteButtonClass} mt-4`}>Xóa dự án chính</button>
              </div>
            ))}
            <button onClick={() => addToArray(setProjects, { title: '', description: '', detailedDescription: '', technologies: [], imageUrl: 'https://picsum.photos/600/400', liveDemoUrl: '#', sourceCodeUrl: '#', mediaGallery: [], subProjects: [] })} className={commonButtonClass}>Thêm dự án</button>
          </div>
        </details>
      </div>

       <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700">
        <details open className="group">
          <summary className="text-2xl font-bold text-white cursor-pointer" style={{ fontFamily: 'var(--font-heading)' }}>Chứng chỉ</summary>
           <div className="mt-6 space-y-8 border-t border-slate-700 pt-6">
            {certifications.map((cert, index) => (
              <div key={index} className="space-y-4 p-4 border border-slate-600 rounded-lg">
                 <ImageUploader label="Ảnh chứng chỉ" currentImageUrl={cert.imageUrl} onImageUrlChange={url => handleArrayChange(setCertifications, index, 'imageUrl', url)} />
                <div><label className={commonLabelClass}>Tên chứng chỉ</label><input type="text" value={cert.name} onChange={e => handleArrayChange(setCertifications, index, 'name', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Đơn vị cấp</label><input type="text" value={cert.issuer} onChange={e => handleArrayChange(setCertifications, index, 'issuer', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>Ngày cấp</label><input type="text" value={cert.date} onChange={e => handleArrayChange(setCertifications, index, 'date', e.target.value)} className={commonInputClass} /></div>
                <div><label className={commonLabelClass}>URL xác thực</label><input type="text" value={cert.verifyUrl} onChange={e => handleArrayChange(setCertifications, index, 'verifyUrl', e.target.value)} className={commonInputClass} /></div>
                <button onClick={() => removeFromArray(setCertifications, index)} className={deleteButtonClass}>Xóa chứng chỉ</button>
              </div>
            ))}
            <button onClick={() => addToArray(setCertifications, { name: '', issuer: '', date: '', imageUrl: 'https://picsum.photos/600/400', verifyUrl: '#' })} className={commonButtonClass}>Thêm chứng chỉ</button>
          </div>
        </details>
      </div>
    </section>
  );
};

export default Settings;