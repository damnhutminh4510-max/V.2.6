import React from 'react';
import { SkillCategory } from '../types';
import { useLanguage } from '../LanguageContext';

interface SkillBarProps {
  name: string;
  level: number; // 0-100
}

const SkillBar: React.FC<SkillBarProps> = ({ name, level }) => {
  return (
    <div>
        <div className="flex justify-between mb-1">
            <span className="text-base font-medium text-slate-300">{name}</span>
            <span className="text-sm font-medium text-slate-400">{level}%</span>
        </div>
        <div className="w-full bg-slate-700 rounded-full h-2.5">
            <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-2.5 rounded-full" style={{width: `${level}%`}}></div>
        </div>
    </div>
  );
};


interface SkillsProps {
  skillCategories: SkillCategory[];
}

const Skills: React.FC<SkillsProps> = ({ skillCategories }) => {
  const { t } = useLanguage();
  return (
    <section className="animate-fadeInUp max-w-4xl mx-auto space-y-12">
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center text-white mb-12 md:mb-16" style={{ fontFamily: 'var(--font-heading)' }}>
        {t('skillsAndAbilities')}
      </h1>
      
      <div className="space-y-8">
        {skillCategories.map((category, index) => (
          <div 
            key={index} 
            className="bg-slate-800/60 backdrop-blur-lg p-6 md:p-8 rounded-2xl shadow-lg border border-slate-700"
          >
            <h2 className="text-2xl font-bold text-white mb-6 border-b-2 border-slate-600 pb-3" style={{ fontFamily: 'var(--font-heading)' }}>
              {category.name}
            </h2>
            <div className="space-y-6">
              {category.skills.map((skill, skillIndex) => (
                <SkillBar key={skillIndex} name={skill.name} level={skill.level} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Skills;