import React from 'react';
import { PersonalInfo, Experience as ExperienceType, Project, Certificate } from '../types';
import ImageSlider from '../components/ImageSlider';
import { useLanguage } from '../LanguageContext';

interface IntroductionProps {
  personalInfo: PersonalInfo;
  workExperience: ExperienceType[];
  projects: Project[];
  certifications: Certificate[];
  isLimitedView: boolean;
}

const InfoItem: React.FC<{ label: string; value: string | number | string[] }> = ({ label, value }) => (
  <div>
    <dt className="font-semibold text-cyan-400">{label}:</dt>
    <dd className="text-slate-300">
      {Array.isArray(value) ? value.join(', ') : value}
    </dd>
  </div>
);

const Introduction: React.FC<IntroductionProps> = ({ personalInfo, workExperience, projects, certifications, isLimitedView }) => {
  const { t } = useLanguage();

  const renderCareerGoal = (goalText: string) => {
    return goalText.split('\n').filter(line => line.trim() !== '').map((line, index) => {
        if (line.startsWith('**') && line.endsWith('**')) {
            return <h4 key={index} className="text-lg font-semibold text-cyan-300 mt-3 list-none">{line.replace(/\*\*/g, '')}</h4>;
        }
        if (line.startsWith('-')) {
            return <li key={index} className="ml-5">{line.substring(1).trim()}</li>;
        }
        return <li key={index} className="list-none">{line}</li>;
    });
  };

  return (
    <section className="animate-fadeInUp">
      <div className="bg-slate-800/60 backdrop-blur-xl rounded-2xl p-4 sm:p-8 border border-slate-700/50 shadow-2xl max-w-6xl mx-auto">
        <div className="space-y-16">
          {!isLimitedView && (
            <div className="max-w-5xl mx-auto bg-slate-900/40 backdrop-blur-sm rounded-xl shadow-2xl overflow-hidden border border-slate-700">
              <header className="p-6 md:p-8 border-b-2 border-slate-700/50">
                <h1 className="text-3xl md:text-4xl font-bold text-white text-center uppercase tracking-widest" style={{ fontFamily: 'var(--font-heading)' }}>
                  {personalInfo.name}
                </h1>
              </header>
              <div className="flex flex-col md:flex-row">
                <aside className="w-full md:w-1/3 bg-transparent p-6">
                  <img 
                    src={personalInfo.avatarUrl} 
                    alt="Avatar" 
                    className="w-full h-auto object-cover rounded-lg shadow-lg" 
                  />
                  <div className="mt-6 border-t border-slate-700 pt-6 space-y-4">
                    <h3 className="text-xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>{t('personalInfo')}</h3>
                    <InfoItem label={t('age')} value={`${personalInfo.age} ${t('yearsOld')}`} />
                    <InfoItem label={t('address')} value={personalInfo.address} />
                    <InfoItem label={t('school')} value={personalInfo.school} />
                  </div>
                </aside>
                <main className="w-full md:w-2/3 p-6 md:p-8 space-y-8">
                  <div id="career-goals">
                    <h2 className="text-2xl font-bold text-white border-l-4 border-cyan-500 pl-4 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                      {t('careerGoals')}
                    </h2>
                    <ul className="text-slate-300 space-y-2 list-disc list-outside ml-1">
                      {renderCareerGoal(personalInfo.careerGoal)}
                    </ul>
                  </div>
                  <div className="border-t border-slate-700"></div>
                  <div id="work-experience">
                    <h2 className="text-2xl font-bold text-white border-l-4 border-cyan-500 pl-4 mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                      {t('workExperience')}
                    </h2>
                    <div className="space-y-6">
                      {workExperience.map((exp, index) => (
                        <div key={index}>
                          <div className="flex flex-col sm:flex-row justify-between sm:items-baseline mb-1">
                              <h3 className="text-lg font-bold text-cyan-300">{exp.company}</h3>
                              <p className="text-sm text-slate-400 flex-shrink-0">{exp.period}</p>
                          </div>
                          <p className="font-semibold text-white mb-2">{exp.jobTitle}</p>
                          <ul className="list-disc list-inside space-y-1 text-slate-300">
                            {exp.responsibilities.map((resp, i) => (
                              <li key={i}>{resp}</li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </div>
                </main>
              </div>
            </div>
          )}
          
          <ImageSlider title={t('featuredProjects')} items={projects} />
          <ImageSlider title={t('CERTIFICATIONS')} items={certifications} />
        </div>
      </div>
    </section>
  );
};

export default Introduction;