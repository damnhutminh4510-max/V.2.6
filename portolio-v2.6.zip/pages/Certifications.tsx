import React, { useRef, useEffect } from 'react';
import { Certificate } from '../types';
import { useLanguage } from '../LanguageContext';

interface CertificationsProps {
  certifications: Certificate[];
}

const Certifications: React.FC<CertificationsProps> = ({ certifications }) => {
  const { t, language } = useLanguage();
  const imageRefs = useRef<(HTMLImageElement | null)[]>([]);

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          imageRefs.current.forEach(img => {
            if (!img || !img.parentElement) return;

            const parentRect = img.parentElement.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            if (parentRect.bottom < 0 || parentRect.top > viewportHeight) return;
            
            const elementCenter = parentRect.top + parentRect.height / 2;
            const viewportCenter = viewportHeight / 2;
            const centerOffset = (elementCenter - viewportCenter) / viewportCenter;
            const maxOffset = 20;
            const parallaxOffset = Math.max(-maxOffset, Math.min(maxOffset, centerOffset * -maxOffset));
            
            img.style.transform = `scale(1.15) translateY(${parallaxOffset}px)`;
          });
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [certifications]);
  
  const getLocalizedText = (viText: string, enText: string) => language === 'vi' ? viText : enText;

  return (
    <section className="animate-fadeInUp">
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center text-white mb-12 md:mb-16" style={{ fontFamily: 'var(--font-heading)' }}>{t('CERTIFICATIONS')}</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 stagger-children [perspective:1000px]">
        {certifications.map((cert, index) => (
           <div 
             key={index} 
             className="group relative bg-slate-800/60 rounded-2xl shadow-lg overflow-hidden border border-slate-700/50 flex flex-col [transform-style:preserve-3d] transition-all duration-500 ease-out hover:shadow-cyan-400/20 hover:[transform:rotateX(3deg)_rotateY(-4deg)_scale(1.03)]"
             style={{ animationDelay: `${index * 0.15}s` }}
            >
             <div className="absolute -inset-px bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl opacity-0 group-hover:opacity-70 transition-opacity duration-300"></div>
             <div className='relative flex flex-col flex-grow'>
                <div className="h-48 overflow-hidden">
                    <img 
                        ref={el => { imageRefs.current[index] = el; }}
                        src={cert.imageUrl} 
                        alt={cert.name} 
                        className="w-full h-full object-cover transition-transform duration-300"
                        style={{transform: 'scale(1.15)'}}
                    />
                </div>
               <div className="p-6 flex flex-col flex-grow">
                 <h3 className="text-xl font-semibold text-white mb-2 flex-grow" style={{ fontFamily: 'var(--font-heading)' }}>{cert.name}</h3>
                 <p className="text-cyan-400 mb-1">{getLocalizedText('Cấp bởi', 'Issued by')}: {cert.issuer}</p>
                 <p className="text-slate-400 text-sm mb-6">{getLocalizedText('Ngày cấp', 'Date')}: {cert.date}</p>
                 {cert.verifyUrl && (
                    <a href={cert.verifyUrl} target="_blank" rel="noopener noreferrer" className="mt-auto block text-center bg-slate-700/80 text-white font-bold py-2.5 px-4 rounded-lg hover:bg-cyan-500 transition-colors duration-200">
                      {t('verify')}
                    </a>
                  )}
               </div>
             </div>
         </div>
        ))}
      </div>
    </section>
  );
};

export default Certifications;