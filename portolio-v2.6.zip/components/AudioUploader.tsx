import React, { useRef } from 'react';

interface AudioUploaderProps {
  label: string;
  currentAudioUrl: string;
  onAudioUrlChange: (newUrl: string) => void;
}

const AudioUploader: React.FC<AudioUploaderProps> = ({ label, currentAudioUrl, onAudioUrlChange }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isFileUploaded = currentAudioUrl.startsWith('data:audio');

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onAudioUrlChange(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUrlChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onAudioUrlChange(event.target.value);
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-cyan-400">{label}</label>
      <div className="flex-grow space-y-2">
        <input
          type="text"
          placeholder={isFileUploaded ? "Đã tải lên tệp cục bộ. Xóa để nhập URL." : "Dán URL tệp âm thanh vào đây"}
          value={isFileUploaded ? "" : currentAudioUrl}
          onChange={handleUrlChange}
          disabled={isFileUploaded}
          className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed"
        />
        <input
          type="file"
          accept="audio/*"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
        <div className="flex gap-2">
             <button
                type="button"
                onClick={triggerFileSelect}
                className="flex-1 bg-slate-700 text-white font-semibold py-2 px-4 rounded-md hover:bg-slate-600 transition-colors duration-200"
            >
                Tải lên từ máy tính
            </button>
            {currentAudioUrl && (
                <button
                    type="button"
                    onClick={() => onAudioUrlChange('')}
                    className="bg-red-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-red-500 transition-colors duration-200"
                >
                    Xóa
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default AudioUploader;