import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { MediaItem } from '../types';

interface LightboxProps {
  isOpen: boolean;
  onClose: () => void;
  media: MediaItem[];
  startIndex?: number;
}

const Lightbox: React.FC<LightboxProps> = ({ isOpen, onClose, media, startIndex = 0 }) => {
  const [currentIndex, setCurrentIndex] = useState(startIndex);

  useEffect(() => {
    setCurrentIndex(startIndex);
  }, [startIndex, isOpen]);
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') {
        goToNext();
      } else if (e.key === 'ArrowLeft') {
        goToPrevious();
      } else if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, currentIndex]);

  if (!isOpen || !media || media.length === 0) return null;
  
  const goToPrevious = () => {
    setCurrentIndex(prevIndex => (prevIndex === 0 ? media.length - 1 : prevIndex - 1));
  };
  
  const goToNext = () => {
    setCurrentIndex(prevIndex => (prevIndex === media.length - 1 ? 0 : prevIndex + 1));
  };

  const currentMedia = media[currentIndex];
  
  return ReactDOM.createPortal(
    <div
      className="fixed inset-0 bg-black/90 backdrop-blur-sm flex justify-center items-center z-[1000] animate-fadeIn p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full h-full flex items-center justify-center" onClick={e => e.stopPropagation()}>
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-white hover:text-cyan-400 transition-colors z-20 bg-black/50 p-2 rounded-full"
          aria-label="Close"
        >
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
        
        {media.length > 1 && (
            <>
            {/* Previous Button */}
            <button
                onClick={goToPrevious}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-white hover:text-cyan-400 transition-colors z-20 bg-black/50 p-3 rounded-full"
                aria-label="Previous image"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>

            {/* Next Button */}
            <button
                onClick={goToNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-white hover:text-cyan-400 transition-colors z-20 bg-black/50 p-3 rounded-full"
                aria-label="Next image"
            >
                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>
            </>
        )}


        {/* Media Content */}
        <div className="max-w-[90vw] max-h-[85vh] flex flex-col items-center justify-center animate-subtleZoomIn">
          {currentMedia.type === 'image' ? (
            <img src={currentMedia.url} alt={currentMedia.caption || `Media ${currentIndex + 1}`} className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" />
          ) : (
            <video src={currentMedia.url} controls className="max-w-full max-h-full object-contain rounded-lg shadow-2xl" />
          )}
          {currentMedia.caption && (
             <p className="text-white text-center mt-4 bg-black/50 px-4 py-2 rounded-lg">{currentMedia.caption}</p>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
};

export default Lightbox;