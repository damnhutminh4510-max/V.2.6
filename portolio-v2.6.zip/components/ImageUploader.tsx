import React, { useRef } from 'react';
import { useLanguage } from '../LanguageContext';

interface ImageUploaderProps {
  label: string;
  currentImageUrl: string;
  onImageUrlChange: (newUrl: string) => void;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ label, currentImageUrl, onImageUrlChange }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { t } = useLanguage();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onImageUrlChange(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUrlChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onImageUrlChange(event.target.value);
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-cyan-400">{label}</label>
      <div className="flex items-center gap-4">
        <img src={currentImageUrl} alt="Preview" className="w-20 h-20 rounded-lg object-cover border-2 border-slate-600" />
        <div className="flex-grow space-y-2">
          <input
            type="text"
            placeholder="Hoặc dán URL hình ảnh vào đây"
            value={currentImageUrl.startsWith('data:') ? '' : currentImageUrl}
            onChange={handleUrlChange}
            className="w-full bg-slate-900 border border-slate-700 rounded-md px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          <button
            type="button"
            onClick={triggerFileSelect}
            className="w-full bg-slate-700 text-white font-semibold py-2 px-4 rounded-md hover:bg-slate-600 transition-colors duration-200"
          >
            {t('uploadFromComputer')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageUploader;