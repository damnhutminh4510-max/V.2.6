import React, { useState } from 'react';
import { Page, PersonalInfo } from '../types';
import { useLanguage } from '../LanguageContext';

interface HeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  personalInfo: PersonalInfo;
  isLocked: boolean;
  isAuthenticated: boolean;
  onLogout: () => void;
}

const LanguageSwitcher: React.FC = () => {
    const { language, setLanguage } = useLanguage();
    
    const toggleLanguage = () => {
        setLanguage(language === 'vi' ? 'en' : 'vi');
    };

    return (
        <button
            onClick={toggleLanguage}
            className="flex items-center justify-center w-10 h-10 rounded-full bg-[var(--header-bg-color)] backdrop-blur-lg border border-white/10 text-[var(--header-text-color)] hover:bg-white/20 font-semibold text-sm transition-all duration-300"
            aria-label="Change language"
        >
            {language.toUpperCase()}
        </button>
    );
};

const Header: React.FC<HeaderProps> = ({ currentPage, setCurrentPage, personalInfo, isLocked, isAuthenticated, onLogout }) => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { t } = useLanguage();
  const navItems = Object.values(Page);

  const handleNavClick = (page: Page) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
  }

  const handleLogoutClick = () => {
    onLogout();
    setMobileMenuOpen(false);
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 p-4">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setCurrentPage(Page.Introduction)}
          >
             <div className="w-10 h-10 bg-[var(--accent-color)] rounded-full flex items-center justify-center overflow-hidden">
                {personalInfo.logoUrl ? (
                  <img src={personalInfo.logoUrl} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-white font-bold text-2xl" style={{fontFamily: 'var(--font-heading)'}}>M</span>
                )}
            </div>
            <span 
              className="text-2xl font-bold text-white hidden sm:block"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {personalInfo.portfolioName}
            </span>
          </div>

          {/* Desktop Navigation */}
          {!isLocked && (
            <nav className="hidden md:flex items-center gap-2">
              <div className="flex items-center bg-[var(--header-bg-color)] backdrop-blur-lg border border-white/10 rounded-full p-1">
                {navItems.filter(item => item !== Page.Settings).map((item) => (
                  <button
                    key={item}
                    onClick={() => handleNavClick(item)}
                    className={`px-4 py-2 text-sm font-semibold rounded-full transition-all duration-300 ${
                      currentPage === item
                        ? 'bg-[var(--accent-color)] text-white shadow-md'
                        : 'text-[var(--header-text-color)] hover:bg-white/10'
                    }`}
                  >
                    {t(item)}
                  </button>
                ))}
              </div>
               <button
                  onClick={() => handleNavClick(Page.Settings)}
                  aria-label={t('SETTINGS')}
                  className={`flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300 ${
                      currentPage === Page.Settings
                      ? 'bg-[var(--accent-color)] text-white shadow-md'
                      : 'bg-[var(--header-bg-color)] backdrop-blur-lg border border-white/10 text-[var(--header-text-color)] hover:bg-white/20'
                  }`}
              >
                 <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              </button>
               {isAuthenticated && (
                <button
                  onClick={onLogout}
                  aria-label={t('logout')}
                  className="flex items-center justify-center w-10 h-10 rounded-full bg-red-600/80 text-white hover:bg-red-500 transition-colors duration-300 backdrop-blur-lg border border-white/10"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                </button>
              )}
              <LanguageSwitcher />
            </nav>
          )}
          
          {/* Mobile Menu Button */}
          {!isLocked && (
            <div className="md:hidden flex items-center gap-2">
              <LanguageSwitcher />
              <button
                onClick={() => setMobileMenuOpen(!isMobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-slate-300 bg-white/10 hover:bg-white/20 focus:outline-none"
                aria-controls="mobile-menu"
                aria-expanded={isMobileMenuOpen}
              >
                <span className="sr-only">{t('openMainMenu')}</span>
                {isMobileMenuOpen ? (
                  <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                ) : (
                  <svg className="block h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                )}
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Mobile Menu */}
      {!isLocked && isMobileMenuOpen && (
        <div className="md:hidden mt-4" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 bg-slate-800/90 backdrop-blur-lg rounded-lg">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => handleNavClick(item)}
                className={`${
                  currentPage === item
                    ? 'bg-[var(--accent-color)] text-white'
                    : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                } block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                {t(item)}
              </button>
            ))}
             {isAuthenticated && (
              <button
                onClick={handleLogoutClick}
                className="bg-red-600/90 text-white block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 mt-2"
              >
                {t('logout')}
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;