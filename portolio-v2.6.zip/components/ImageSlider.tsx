import React from 'react';

interface SliderItem {
  imageUrl: string;
  title?: string;
  name?: string;
}

interface ImageSliderProps {
  title: string;
  items: SliderItem[];
}

const ImageSlider: React.FC<ImageSliderProps> = ({ title, items }) => {
  if (!items || items.length === 0) {
    return null;
  }
  
  // Duplicate items for a seamless loop
  const doubledItems = [...items, ...items];

  return (
    <section>
      <h2 className="text-3xl font-bold text-white mb-8 text-center" style={{ fontFamily: 'var(--font-heading)' }}>
        {title}
      </h2>
      <div
        className="group relative w-full overflow-hidden"
        style={{
          maskImage: 'linear-gradient(to right, transparent 0%, black 10%, black 90%, transparent 100%)'
        }}
      >
        <div 
          className="flex w-fit animate-[marquee_var(--slider-animation-duration)_linear_infinite] group-hover:[animation-play-state:paused]"
          style={{ animationName: 'marquee', animationDuration: 'var(--slider-animation-duration,30s)', animationTimingFunction: 'linear', animationIterationCount: 'infinite' }}
        >
          {doubledItems.map((item, index) => (
            <div key={index} className="flex-shrink-0 w-64 sm:w-80 px-4">
              <div className="group/item relative bg-slate-800/50 rounded-2xl border border-slate-700/50 shadow-lg overflow-hidden h-full transform transition-transform duration-300 hover:-translate-y-2">
                <img
                  src={item.imageUrl}
                  alt={item.title || item.name || ''}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                 <p className="absolute bottom-0 left-0 right-0 p-4 text-white font-semibold truncate transition-all duration-300 group-hover/item:text-cyan-300" style={{ fontFamily: 'var(--font-heading)' }}>
                    {item.title || item.name}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImageSlider;