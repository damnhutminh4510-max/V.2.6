import React from 'react';

const LoadingSpinner: React.FC = () => (
  <div className="flex justify-center items-center min-h-screen bg-slate-900">
    <div className="relative flex items-center justify-center">
        <div className="absolute h-24 w-24 rounded-full border-4 border-t-transparent border-cyan-400 animate-spin"></div>
        <div className="text-white font-bold text-2xl" style={{fontFamily: 'var(--font-heading)'}}>M</div>
    </div>
  </div>
);

export default LoadingSpinner;
