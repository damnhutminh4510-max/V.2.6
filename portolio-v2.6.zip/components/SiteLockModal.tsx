import React, { useState } from 'react';
import { useLanguage } from '../LanguageContext';

interface SiteLockModalProps {
  onUnlock: (password: string) => boolean;
  onAdminLogin: (username: string, password: string) => boolean;
}

const SiteLockModal: React.FC<SiteLockModalProps> = ({ onUnlock, onAdminLogin }) => {
  const [mode, setMode] = useState<'password' | 'admin'>('password');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [error, setError] = useState('');
  const { t } = useLanguage();

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const isSuccess = onUnlock(password);
    if (!isSuccess) {
      setError(t('wrongPassword'));
      setPassword('');
    } else {
        setError('');
    }
  };

  const handleAdminSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const isSuccess = onAdminLogin(username, adminPassword);
    if (!isSuccess) {
        setError(t('wrongAdminCredentials'));
        setAdminPassword('');
    } else {
        setError('');
    }
  };

  const switchMode = (newMode: 'password' | 'admin') => {
    setMode(newMode);
    setError('');
    setPassword('');
    setUsername('');
    setAdminPassword('');
  }
  
  const commonInputClass = "w-full bg-slate-900/80 border border-slate-600 rounded-lg px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-all";
  const commonButtonClass = "w-full bg-cyan-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-cyan-500 transition-colors duration-200 shadow-lg shadow-cyan-500/20";

  return (
    <div className="fixed inset-0 bg-slate-900/70 flex justify-center items-center z-[1000] p-4 animate-fadeIn">
      <div className="w-full max-w-sm animate-subtleZoomIn">
        <div className="bg-slate-800/80 backdrop-blur-xl p-8 rounded-2xl shadow-2xl border border-slate-700/80">
            {mode === 'password' ? (
                <>
                    <h2 className="text-2xl font-bold text-center text-white mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
                        {t('accessRequired')}
                    </h2>
                    <p className="text-slate-400 text-center mb-6">{t('enterPasswordPrompt')}</p>
                    <form onSubmit={handlePasswordSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="site-password" className="sr-only">{t('password')}</label>
                            <input
                              id="site-password"
                              type="password"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              required
                              placeholder="••••••••"
                              className={`${commonInputClass} text-center tracking-[0.2em]`}
                              autoFocus
                            />
                        </div>
                        {error && <p className="text-red-500 text-sm text-center -mb-2">{error}</p>}
                        <div>
                            <button type="submit" className={commonButtonClass}>
                                {t('unlock')}
                            </button>
                        </div>
                    </form>
                    <button onClick={() => switchMode('admin')} className="text-xs text-slate-400 hover:text-cyan-400 text-center w-full mt-5 transition-colors">
                        {t('forgotPassword')}
                    </button>
                </>
            ) : (
                 <>
                    <h2 className="text-2xl font-bold text-center text-white mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                        {t('adminLoginTitle')}
                    </h2>
                    <form onSubmit={handleAdminSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="admin-username" className="sr-only">{t('username')}</label>
                             <input
                              id="admin-username"
                              type="text"
                              value={username}
                              onChange={(e) => setUsername(e.target.value)}
                              required
                              placeholder={t('username')}
                              className={commonInputClass}
                              autoFocus
                            />
                        </div>
                        <div>
                           <label htmlFor="admin-password" className="sr-only">{t('password')}</label>
                           <input
                              id="admin-password"
                              type="password"
                              value={adminPassword}
                              onChange={(e) => setAdminPassword(e.target.value)}
                              required
                              placeholder={t('password')}
                              className={commonInputClass}
                            />
                        </div>

                        {error && <p className="text-red-500 text-sm text-center -mb-2">{error}</p>}
                        <div>
                            <button type="submit" className={commonButtonClass}>
                                {t('adminLoginAndUnlock')}
                            </button>
                        </div>
                    </form>
                     <button onClick={() => switchMode('password')} className="text-xs text-slate-400 hover:text-cyan-400 text-center w-full mt-5 transition-colors">
                        {t('enterSitePassword')}
                    </button>
                </>
            )}
        </div>
      </div>
    </div>
  );
};

export default SiteLockModal;