import React from 'react';

interface MusicPlayerProps {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  hasMusic: boolean;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ isPlaying, setIsPlaying, hasMusic }) => {
  if (!hasMusic) {
    return null;
  }

  return (
    <button
      onClick={() => setIsPlaying(!isPlaying)}
      className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-slate-800/80 backdrop-blur-lg border border-slate-700 rounded-full flex items-center justify-center text-cyan-400 hover:text-white hover:bg-cyan-500/50 transition-all duration-300 shadow-lg focus:outline-none focus:ring-2 focus:ring-cyan-500"
      aria-label={isPlaying ? 'Tạm dừng nhạc' : 'Phát nhạc'}
    >
      {isPlaying ? (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
      )}
    </button>
  );
};

export default MusicPlayer;
