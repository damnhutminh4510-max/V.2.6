// @ts-nocheck

declare const firebase: any;

// This configuration is loaded from environment variables.
// You need to set these up in your deployment platform (e.g., Netlify).
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY,
  authDomain: process.env.FIREBASE_AUTH_DOMAIN,
  projectId: process.env.FIREBASE_PROJECT_ID,
  storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.FIREBASE_APP_ID,
};

// Check if all required config values are present.
const isConfigComplete = Object.values(firebaseConfig).every(value => value);

let firestoreInstance = null;
let firebaseError = null;

if (typeof firebase === 'undefined') {
    firebaseError = "Firebase SDK not loaded. Please check your internet connection and index.html file.";
    console.error(firebaseError);
} else if (!isConfigComplete) {
    firebaseError = "Firebase configuration is incomplete. Please check your environment variables in Netlify.";
    console.error(firebaseError, "Missing config:", firebaseConfig);
} else {
    try {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        }
        firestoreInstance = firebase.firestore();
    } catch (e) {
        firebaseError = `Firebase initialization error: ${e.message}`;
        console.error(firebaseError, e);
    }
}

export const firestore = firestoreInstance;
export const firebaseInitializationError = firebaseError;